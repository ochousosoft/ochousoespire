import { Component, OnInit } from '@angular/core';
import { Validators, FormControl, FormGroup } from '@angular/forms';

import { CustomValidators } from 'ng2-validation';

@Component({
    templateUrl: 'form-layouts.html'
})
export class FormLayoutsComponent implements OnInit {

    ngOnInit() {
        
    }
}