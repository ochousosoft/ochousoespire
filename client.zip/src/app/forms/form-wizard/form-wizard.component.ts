import {Component} from '@angular/core';

@Component({
    templateUrl: 'form-wizard.html'
})
export class FormWizard_Component {
    constructor() { }
}