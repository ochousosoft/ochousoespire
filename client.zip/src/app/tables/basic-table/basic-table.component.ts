import { Component } from '@angular/core';

@Component ({
    templateUrl: 'basic-table.html'
})

export class BasicTableComponent {
    constructor() { }
}