import { Component } from '@angular/core';

@Component ({
    templateUrl: 'social.html'
})

export class SocialComponent {
    constructor() { }
}