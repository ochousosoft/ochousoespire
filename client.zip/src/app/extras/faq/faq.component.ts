import { Component } from '@angular/core';

@Component ({
    templateUrl: 'faq.html'
})

export class FAQComponent {
    constructor() { }
}