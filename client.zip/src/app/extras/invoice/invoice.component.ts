import { Component } from '@angular/core';

@Component ({
    templateUrl: 'invoice.html'
})

export class InvoiceComponent {
    constructor() { }
}