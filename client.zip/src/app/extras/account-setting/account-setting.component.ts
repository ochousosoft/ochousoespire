import { Component } from '@angular/core';

@Component ({
    templateUrl: 'account-setting.html'
})

export class AccountSettingComponent {
    constructor() { }
}