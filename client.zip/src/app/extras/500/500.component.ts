import { Component } from '@angular/core';

@Component ({
    templateUrl: '500.html'
})

export class Page500Component {
    constructor() { }
}