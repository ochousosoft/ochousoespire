import { Component } from '@angular/core';

@Component ({
    templateUrl: 'sign-in2.html'
})

export class SignIn2Component {
    constructor() { }
}