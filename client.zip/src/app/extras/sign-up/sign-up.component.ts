import { Component } from '@angular/core';

@Component ({
    templateUrl: 'sign-up.html'
})

export class SignUpComponent {
    constructor() { }
}