import { Injectable } from '@angular/core';

@Injectable()
export class Constants {

  constructor() {

  }


  public static API_URL = 'http://ochouso.gal:8013/server/api';
  //public static API_URL = 'http://localhost:8013/server/api';

}
