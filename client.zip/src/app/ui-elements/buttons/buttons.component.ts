import { Component } from '@angular/core';

@Component({
    templateUrl: 'buttons.html'
})
export class ButtonsComponent {
    constructor() { }
}
