import {Component} from '@angular/core';

@Component({
    templateUrl: 'modals.html'
})
export class ModalsComponent {
    constructor() { }
}