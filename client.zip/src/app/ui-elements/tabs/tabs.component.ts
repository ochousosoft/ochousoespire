import {Component} from '@angular/core';

@Component({
    templateUrl: 'tabs.html'
})
export class TabsComponent {
    constructor() { }
}