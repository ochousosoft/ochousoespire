import { Component } from '@angular/core';

@Component ({
    templateUrl: 'cards.html'
})

export class CardsComponent {
    constructor() { }
}